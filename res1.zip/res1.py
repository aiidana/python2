import tkinter as tk
from tkinter import ttk

def find_poles_numerically(denominator):
    poles = []

    for i in range(-10, 11, 1):
        substituted_denominator = denominator.replace('z', str(i))
        value = eval(substituted_denominator)
        if value == 0:
            poles.append(i)

    return poles

def residue_numerator(func):
    numerator = str(func.split('/')[0]) 
    numerator = numerator.replace('z', 'z.conjugate()')
    return numerator

def limit_integer(function, approach):
    try:
        # Define 'z' here
        z = approach
        return eval(function)
    except (ZeroDivisionError, ValueError):
        return "Error: Cannot evaluate the limit."

def find_residue(func):
    denom = str(func.split('/')[1])  # Convert to string
    z0 = find_poles_numerically(denom)
    results = []

    for pole in z0:
        try:
            z = pole
            numerator = residue_numerator(func)
            limit_value = limit_integer(numerator, z)

            results.append((pole, limit_value))
        except ZeroDivisionError:
            results.append((pole, "Error: Cannot evaluate the limit (division by zero)."))

    return results

def calculate_residue():
    expression = entry.get()
    result = find_residue(expression)
    result_text.config(state=tk.NORMAL)
    result_text.delete("1.0", tk.END)
    
    for pole, residue in result:
        result_text.insert(tk.END, f"Residue at z = {pole} is: {residue}\n")
    
    result_text.config(state=tk.DISABLED)

root = tk.Tk()
root.title("Residue Calculator")


label = ttk.Label(root, text="Enter a complex function (e.g., (z**2 + 2*z + 3)/(z-1)):")
label.pack(pady=10)

entry = ttk.Entry(root, width=40)
entry.pack(pady=10)

calculate_button = ttk.Button(root, text="Calculate Residue", command=calculate_residue)
calculate_button.pack(pady=10)

result_text = tk.Text(root, height=10, width=40, state=tk.DISABLED)
result_text.pack(pady=10)


root.mainloop()
