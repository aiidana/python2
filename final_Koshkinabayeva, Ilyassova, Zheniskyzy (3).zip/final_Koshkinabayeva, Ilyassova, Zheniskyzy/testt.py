import math
#муавр--------------- z^n ----------------------
# def complexx(a,b,n):
#     def tetta(a,b):
#         if a>0 and b>0:
#             return math.atan(b/a)
#         elif a>0 and b<0:
#             return 2*math.pi - math.atan(b/a)
#         elif a<0 and b>=0:
#            return math.pi- math.atan(b/a)
#         elif a<0 and b<0:
#             return math.pi + math.atan(b/a)
#         elif a==0 and b>=0:
#             return math.pi/2
#         elif a==0 and b<0:
#             return 3*math.pi /2
    
#     #z^n
#     mod_z=math.sqrt(a**2+(b**2))
#     x=(mod_z**n)*math.cos(n*tetta(a,b))
#     y=(mod_z**n)*math.sin(n*tetta(a,b))
#     result = complex(x, y)
#     return result
# print(complexx(1,-1*math.sqrt(3),6))

#------------------z^1/n--------------------------
# def sqr_complex(a,b,n):
#     def tetta(a,b):
#         if a>0 and b>=0:
#             return math.atan(b/a)
#         elif a>0 and b<=0:
#             return 2*math.pi - math.atan(b/a)
#         elif a<0 and b>=0:
#            return math.pi- math.atan(b/a)
#         elif a<0 and b<0:
#             return math.pi + math.atan(b/a)
#         elif a==0 and b>=0:
#             return math.pi/2
#         elif a==0 and b<0:
#             return 3*math.pi /2
#     mod_z=math.sqrt(a**2+(b**2))
#     root=[]
#     for k in range(0,n):
#         phi=(tetta(a,b)+2*k*math.pi)/n
#         x=(mod_z**(1/n))*math.cos(phi)
#         y=(mod_z**(1/n))*math.sin(phi)
#         result=complex(x,y)
#         root.append(result)
#     return f"z={root}"
# print(sqr_complex(1,0,3))

# -----------firstderivative ->numerical--------------
# def numerical(expression,x):
#     def num_derivative(f, x, h=1e-5):
#        return (f(x + h) - f(x - h)) / (2 * h)
#     def function(x):
#         return eval(expression)
#     first_der=num_derivative(function,x)
#     return f"The approximate first derivative at the point {x} :{first_der}"
# expression=input("Enter function f(x):")
# x=float(input('Enter the value of x:'))
# print(numerical(expression,x))

# -------------second derivative-> numerical-----------
# def numerical_sec(expression,x):
#     def num_second(f,x,h=1e-5):
#         return ((f(x+h)-2*f(x)+f(x-h))/(h**2))
#     def function(x):
#         return eval(expression)
#     sec_der=num_second(function,x)
#     return f"The approximate second derivative  at the point {x} :{sec_der}"
# expression=input("Enter function f(x):")
# x=float(input('Enter the value of x:'))
# print(numerical_sec(expression,x))


# -------------- Cauchy- integral ----------------
# |z|=r 


# def numerical(expression, x):
#     def num_derivative(f, x, h=1e-5):
#         return (f(x + h) - f(x - h)) / (2 * h)
#     def function(x):
#         return eval(expression)
#     first_der = num_derivative(function, x)
#     return f"The approximate first derivative at the point {x}: {first_der}"

# def numerical_sec(expression, x):
#     def num_second(f, x, h=1e-5):
#         return ((f(x + h) - 2 * f(x) + f(x - h)) / (h**2))
#     def function(x):
#         return eval(expression)
#     sec_der = num_second(function, x)
#     return f"The approximate second derivative at the point {x}: {sec_der}"

import math

# def cauchy_intg(expression, denominator, r, x, n):
#     def num_derivative(f, x, h=1e-5):
#         return (f(x + h) - f(x - h)) / (2 * h)

#     def num_second(f, x, h=1e-5):
#         return ((f(x + h) - 2 * f(x) + f(x - h)) / (h**2))

#     def function(z):
#         return eval(expression)

#     def factorial(n):
#         fact = 1
#         for i in range(1, n+1):
#             fact *= i
#         return fact

#     result = []
#     if abs(denominator - x) <= r:
#         if n == 0:
#             result.append(0)
#         if n == 1:
#             result.append(complex((1j * 2 * math.pi * function(denominator))))
#         if n == 2:
#             result.append(complex(1j * 2 * math.pi * num_derivative(function, denominator))/factorial(n-1))
#         if n == 3:
#             result.append(complex(1j * 2 * math.pi * num_second(function, denominator)) / factorial(n-1))
#     else:
#         result.append("The condition |z0 - x| <= r is not satisfied.")
#     return result

# expression = input("Enter function f(z): ")
# denominator = int(input("z-z0, enter z0="))
# r = float(input("Enter radius: "))
# x = float(input("Enter контур C(z-x)->x= "))
# n = int(input("Enter degree of (z - z0): "))

# print(cauchy_intg(expression, denominator, r, x, n))


#--------------- Partial derivative------------------------
# def f_x(expression, x, y):
#     def fx(f,x, y, h=1e-5):  #  with respect to x
#         return (f(x + h, y) - f(x - h, y)) / (2 * h)
#     def function(x, y):
#         return eval(expression)
#     ftox = fx(function,x, y)
#     return ftox
# def f_y(expression,x,y):
#     def fy(f,x,y,h=1e-5): # with respect to y
#       return (f(x, y+h)-f(x, y-h))/(2*h)
#     def function(x, y):
#         return eval(expression)
#     ftoy = fy(function,x, y)
#     return ftoy

# expression = input("Enter function f(x,y): ")
# x_val = float(input("Enter the value of x: "))
# y_val = float(input("Enter the value of y: "))
# print(f_y(expression, x_val, y_val))

#--------------- analytic------------------------
# def analytic(u,v,x,y):
#     def fx(f,x, y, h=1e-5):  # Partial derivative with respect to x
#         return (f(x + h, y) - f(x - h, y)) / (2 * h)
#     def fy(f,x,y,h=1e-5):    #Partial derivative with respect to y
#       return (f(x, y+h)-f(x, y-h))/(2*h)
#     def u_func(x, y):
#       return eval(u)
#     def v_func(x, y):
#         return eval(v)
#     ux=fx(u_func,x,y)
#     vy=fy(v_func,x,y)
#     uy=fy(u_func,x,y)
#     vx=fx(v_func,x,y)
#     check1=ux-vy
#     check2=uy+vx
#     if check1==0 and check2==0:
#         return f'Function is analytic-> ux={ux},vy={vy},vx={vx},uy={uy}'
#     else:
#         return "Function is not analytic"
# u=input('u function:')
# v=input('v function:')
# x=1
# y=1
# print(analytic(u,v,x,y))



  

#-------------crititcal points--------------
# def critical_points(expression):
#     def numerical_derivative(f, x, h=1e-5):
#         return (f(x + h) - f(x - h)) / (2 * h)
#     def f(x):
#         return eval(expression)
#     critical_point=[]
#     result=[]
#     for x in range(-200,201):
#         if abs(numerical_derivative(f, x))<=0.000000001:
#             critical_point.append(x)
#     for x in critical_point:
#         left=numerical_derivative(f,x-0.0001)
#         right=numerical_derivative(f,x+0.0001)
#         if left > 0 and right < 0:
#             result.append(f'The point x = {x} is a local maximum')
#         elif left < 0 and right > 0:
#             result.append(f'The point x = {x} is a local minimum')
#     if not result:
#         result.append('No local maxima or minima found')

#     return result
        

# expression=input()
# print(critical_points(expression))

#---------harmonic-----------------
# def u(x, y):
#     return x**2 - y**2

# def v(x, y):
#     return 2 * x * y

# def is_harmonic_u(u, x, y, delta=0.0001):
#     uxx = (u(x + delta, y) - 2 * u(x, y) + u(x - delta, y)) / (delta**2)
#     uyy = (u(x, y + delta) - 2 * u(x, y) + u(x, y - delta)) / (delta**2)
#     return abs(uxx + uyy) < delta

# def is_harmonic_v(v, x, y, delta=0.0001):
#     vxy = (v(x + delta, y + delta) - v(x + delta, y - delta) - v(x - delta, y + delta) + v(x - delta, y - delta)) / (4 * delta**2)
#     vyx = (v(x + delta, y + delta) - v(x + delta, y - delta) - v(x - delta, y + delta) + v(x - delta, y - delta)) / (4 * delta**2)
#     return abs(vxy - vyx) < delta

# # Example usage:
# x, y = 1.0, 2.0

# # Check if u is harmonic
# if is_harmonic_u(u, x, y):
#     print("u is harmonic")
# else:
#     print("u is not harmonic")

# # Check if v is harmonic
# if is_harmonic_v(v, x, y):
#     print("v is harmonic")
# else:
#     print("v is not harmonic")

#------------limit------------
# def lim_integer(function, approach):
#     # Define basic functions needed for evaluation
#     def sin(x):
#         return math.sin(x)

#     def tan(x):
#         return math.tan(x)

#     def cos(x):
#         return math.cos(x)

#     x = approach
#     try:
#         e = eval(function)
#         if e == sin(x) / x and x == 0: #замечательные пределы
#             lim = 1
#         elif e == tan(x) / x and x == 0:
#             lim = 1
#         elif e == 1 / cos(x) and x == 0:
#             lim = 1
#         elif '/' in str(e):
#             e = str(e).split('/')
#             if int(e[0]) > 0 and int(e[1]) == 0:
#                 lim = "limit equals infinity"
#             elif int(e[0]) == 0 and int(e[1]) == 0:
#                 lim = "limit does not exist"
#             else:
#                 e = "/".join(reversed(str(e).split('/')))
#                 lim = eval(e)
#         else:
#             lim = e
#         return lim  # Return the calculated limit instead of printing it
#     except (ZeroDivisionError, ValueError):
#         return "Error: Cannot evaluate the limit."


#--------------(x+y)^n---------------
# def generate_binomial_expression(coefficient_x, coefficient_y, power):
    

#     try:
        
#         # Define a function to format each term
#         def format_binomial_term(term_value, term_coeffs):
#             if term_value == 1:
#                 term_coeffs.insert(0, "")
#             else:
#                 term_coeffs.insert(0, str(term_value))
#             if term_coeffs[1] == "^0" and term_coeffs[2] == "^0":
#                 return term_coeffs[0]
#             elif term_coeffs[1] == "^0":
#                 return "{}y{}".format(term_coeffs[0], term_coeffs[2])
#             elif term_coeffs[2] == "^0":
#                 return "{}x{}".format(term_coeffs[0], term_coeffs[1])
#             elif term_coeffs[1] == "^1" and term_coeffs[2] == "^1":
#                 return "{}x".format(term_coeffs[0])
#             elif term_coeffs[1] == "^1":
#                 return "{}x{}".format(term_coeffs[0], term_coeffs[2])
#             elif term_coeffs[2] == "^1":
#                 return "x{}y{}".format(term_coeffs[0], term_coeffs[1])
#             return "{}x{}y{}".format(term_coeffs[0], term_coeffs[1], term_coeffs[2])

#         expanded_series = []
#         first_term = pow(coefficient_x, power)
#         term_coeffs = ["^" + str(power), "^0"]
#         expanded_series.append(f"({coefficient_x}x+{coefficient_y}y)^{power} = " + format_binomial_term(first_term, term_coeffs) + "  +  ")
#         next_term = first_term
#         for i in range(1, power + 1):
#             next_term = int(next_term * coefficient_y * (power - i + 1) / (i * coefficient_x))
#             term_coeffs = ["" if x == 1 else "^" + str(x) for x in [power - i, i]]
#             if i != power:
#                 expanded_series.append(format_binomial_term(next_term, term_coeffs) + "  +  ")
#             else:
#                 expanded_series.append(format_binomial_term(next_term, term_coeffs))
        
#         # Display the result in the GUI
#         return "".join(expanded_series)

#     except Exception as e:
#         result_label.config(text="Error: Invalid input")

 

#---------res------------
#проверьте res1.py

#------------tangent line --------------
# def f(x, y, z):
#     return x**2 + y**2 + z**2  # Replace this with your function

# def tangent_plane_equation(f, x0, y0, z0):
#     def partial_derivative_x(f, x, y, z, h=1e-5):
#        return (f(x + h, y, z) - f(x - h, y, z)) / (2 * h)
#     def partial_derivative_y(f, x, y, z, h=1e-5):
#        return (f(x, y + h, z) - f(x, y - h, z)) / (2 * h)
#     def function(x, y,z):
#         return eval(f)
#     fx = partial_derivative_x(function, x0, y0, z0)
#     fy = partial_derivative_y(function, x0, y0, z0)

#     return  f'Equation of the tangent plane : {fx} * (x - {x0}) + {fy} * (y - {y0}) + (z - {z0})=0'


# x0, y0, z0 = 1, 2, 3
# tangent_eq = tangent_plane_equation(f, x0, y0, z0)



# print(f"Equation of the tangent plane at ({x0}, {y0}, {z0}): {tangent_eq} = 0")

#---------gradient
# from math import *
# import numpy as np

# def f(x, y):
#     return np.sin(x + y)**2 + 5 + np.cos(y)**2 - np.exp(-(x**2 + y**2 + 146*y + 54*x + 6058)/25)

# def gradient(f, x0, y0): #finding gradient by finite difference method
#     h = 0.000001
#     # need to multiply to negative one to find descent values
#     df_dx = -1 * (f(x0 + h, y0) - f(x0 - h, y0)) / (2 * h) 
#     df_dy = -1 * (f(x0, y0 + h) - f(x0, y0 - h)) / (2 * h)
#     return np.array([df_dx, df_dy])

# def gradient_descent(x0, y0, num_iter, alpha=0.5, beta=0.95):
    
#     for _ in range(num_iter):
#         t = 1.0 #step size 
#         grad = gradient(f, x0, y0)

#         x1 = x0 + t * grad[0]
#         y1 = y0 + t * grad[1]
#         f1 = f(x1, y1)
#         f0 = f(x0, y0)

#         delta = -(grad[0]**2 + grad[1]**2)
    
#         # backtracking line search
#         while f1 > f0 + alpha * t * delta:
#             t *= beta
#             x1 = x0 + t * grad[0]
#             y1 = y0 + t * grad[1]
#             f1 = f(x1, y1)

#         x0 = x1
#         y0 = y1

#     return (x0, y0, f0)  

# def minimal_value(num_points, num_iterations):
#     x_axis = np.linspace(-100, 100, num_points)
#     y_axis = np.linspace(-100, 100, num_points)

#     iteration = 0
#     minimal_values = []

#     for i in x_axis:
#         for j in y_axis:
#             local_minimal_value = gradient_descent(i, j, num_iterations)
#             minimal_values.append(local_minimal_value)
#             iteration += 1
#             print(f"Iteration {iteration}: {local_minimal_value}")

#     minimal_values.sort(key=lambda x: x[2])
#     print("\nTop 5 results:")
#     for result in minimal_values[:5]:
#         point, value, local_minimal_value = result
#         print(f"Point {np.round(point, 4)}, Value {round(value, 4)}, Minimal Value {round(local_minimal_value, 4)}")

# minimal_value(100, 100)
# """Top 5 results:
# Point -26.7534, Value -73.7871, Minimal Value 4.0286
# Point -26.7534, Value -73.7871, Minimal Value 4.0286
# Point -26.6528, Value -70.7479, Minimal Value 4.1915
# Point -26.6528, Value -70.7479, Minimal Value 4.1915
# Point -26.6528, Value -70.7479, Minimal Value 4.1915-"""


#first derivative простые функции
# def compute_derivative(f, x):
#     derivative = ""
#     terms = f.split('+')

#     
#     for term in terms:
#         if 'x' in term:
#             parts = term.split('*x')
#             coefficient = float(parts[0]) if parts[0] else 1.0
#             power = int(parts[1][2:]) if len(parts) > 1 and '^' in parts[1] else 1

#             if power > 0:
#                 derivative += str(coefficient * power) + "*x^" + str(power - 1) + "+"
    
#     derivative = derivative.rstrip('+')
#     return derivative

# user_input = input(" f(x): ")
# x = input(" x: ")

# derivative = compute_derivative(user_input, x)
# print(f" x={x}: {derivative}")