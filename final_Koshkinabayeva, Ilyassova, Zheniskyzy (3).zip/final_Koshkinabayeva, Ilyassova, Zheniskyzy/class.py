import tkinter as tk
from tkinter import simpledialog
import math
from PIL import Image, ImageTk
import sympy as sp
class Operations:
    #--------------- z^n ----------------------
    def complexx(a,b,n):
        def tetta(a,b):
            if a>0 and b>0:
                return math.atan(b/a)
            elif a>0 and b<0:
                return 2*math.pi - math.atan(b/a)
            elif a<0 and b>=0:
               return math.pi- math.atan(b/a)
            elif a<0 and b<0:
                return math.pi + math.atan(b/a)
            elif a==0 and b>=0:
                return math.pi/2
            elif a==0 and b<0:
                return 3*math.pi /2
            #z^n
        mod_z=math.sqrt(a**2+(b**2))
        x=(mod_z**n)*math.cos(n*tetta(a,b))
        y=(mod_z**n)*math.sin(n*tetta(a,b))
        result = complex(x, y)
        return result 
    #------------------z^1/n--------------------------
    def sqr_complex(a,b,n):
        def tetta(a,b):
            if a>0 and b>=0:
                return math.atan(b/a)
            elif a>0 and b<=0:
                return 2*math.pi - math.atan(b/a)
            elif a<0 and b>=0:
               return math.pi- math.atan(b/a)
            elif a<0 and b<0:
                return math.pi + math.atan(b/a)
            elif a==0 and b>=0:
                return math.pi/2
            elif a==0 and b<0:
                return 3*math.pi /2
        mod_z=math.sqrt(a**2+(b**2))
        root=[]
        for k in range(0,n):
            phi=(tetta(a,b)+2*k*math.pi)/n
            x=(mod_z**(1/n))*math.cos(phi)
            y=(mod_z**(1/n))*math.sin(phi)
            result=complex(x,y)
            root.append(result)
        return f"z={root}"  
    # -----------firstderivative ->numerical--------------
    def numerical(expression,x):
        def num_derivative(f, x, h=1e-5):
           return (f(x + h) - f(x - h)) / (2 * h)
        def function(x):
            return eval(expression)
        first_der=num_derivative(function,x)
        return f"The approximate first derivative at the point {x} :{first_der}"
    # -------------second derivative-> numerical-----------
    def numerical_sec(expression,x):
        def num_second(f,x,h=1e-5):
            return ((f(x+h)-2*f(x)+f(x-h))/(h**2))
        def function(x):
            return eval(expression)
        sec_der=num_second(function,x)
        return f"The approximate second derivative  at the point {x} :{sec_der}"
    #--------------- Partial derivative------------------------
    def f_x(expression, x, y):
        def fx(f,x, y, h=1e-5):  #  with respect to x
            return (f(x + h, y) - f(x - h, y)) / (2 * h)
        def function(x, y):
            return eval(expression)
        ftox = fx(function,x, y)
        return ftox
    def f_y(expression,x,y):
        def fy(f,x,y,h=1e-5): # with respect to y
          return (f(x, y+h)-f(x, y-h))/(2*h)
        def function(x, y):
            return eval(expression)
        ftoy = fy(function,x, y)
        return ftoy
    #--------------- analytic------------------------
    def analytic(u,v,x,y):
        def fx(f,x, y, h=1e-5):  # Partial derivative with respect to x
            return (f(x + h, y) - f(x - h, y)) / (2 * h)
        def fy(f,x,y,h=1e-5):    #Partial derivative with respect to y
          return (f(x, y+h)-f(x, y-h))/(2*h)
        def u_func(x, y):
          return eval(u)
        def v_func(x, y):
            return eval(v)
        ux=fx(u_func,x,y)
        vy=fy(v_func,x,y)
        uy=fy(u_func,x,y)
        vx=fx(v_func,x,y)
        check1=ux-vy
        check2=uy+vx
        if check1==0 and check2==0:
            return f'Function is analytic-> ux={ux},vy={vy},vx={vx},uy={uy}'
        else:
            return "Function is not analytic"
    #--------GCD&LCM-------------------------
    def gcd_lcm(x,y):
        def gcd(x, y):
          while y != 0:
            x, y = y, x % y
          return x
        # gcd*lcm=ab
        gcd_val=gcd(x,y)
        lcm= (x * y) // gcd(x, y)
        return f'gcd={gcd_val} and lcm={lcm}'
    #-----------crititcal points----------------
    def critical_points(expression):
        def numerical_derivative(f, x, h=1e-5):
            return (f(x + h) - f(x - h)) / (2 * h)
        def f(x):
            return eval(expression)
        critical_point=[]
        result=[]
        for x in range(-200,201):
            if abs(numerical_derivative(f, x))<=0.000000001:
                critical_point.append(x)
        for x in critical_point:
            left=numerical_derivative(f,x-0.0001)
            right=numerical_derivative(f,x+0.0001)
            if left > 0 and right < 0:
                result.append(f'The point x = {x} is a local maximum')
            elif left < 0 and right > 0:
                result.append(f'The point x = {x} is a local minimum')
        if not result:
            result.append('No local maxima or minima found')
        return result
    #------------harmonic-----------
    def is_harmonic_u(u, x, y):
        delta=0.0001
        def uxx(u,x,y,delta=0.0001):
            return (u(x + delta, y) - 2 * u(x, y) + u(x - delta, y)) / (delta**2)
        def uyy(u,x,y,delta=0.0001):
            return (u(x, y + delta) - 2 * u(x, y) + u(x, y - delta)) / (delta**2)
        def function(x, y):
            return eval(u)
        u_x=uxx(function,x,y)
        u_y=uyy(function,x,y)
        if u_x+u_y==0:
            result='is harmonic'
        else:
            result='is not harmonic'
        return result

    def is_harmonic_v(v, x, y):
        delta=0.0001
        def vxy(v,x,y,delta=0.0001):
            return (v(x + delta, y + delta) - v(x + delta, y - delta) - v(x - delta, y + delta) + v(x - delta, y - delta)) / (4 * delta**2)
        def vyx(v,x,y,delta=0.0001):
            return (v(x + delta, y + delta) - v(x + delta, y - delta) - v(x - delta, y + delta) + v(x - delta, y - delta)) / (4 * delta**2)
        def function(x, y):
            return eval(v)
        v_x=vxy(function,x,y)
        v_y=vyx(function,x,y)
        if abs(v_x-v_y)==0:
            result='is harmonic'
        else:
            result="is not harmonic"
        return result
    #---------Cauchy Integral-------------
    def cauchy_intg(expression, denominator, r, x, n):
        def num_derivative(f, x, h=1e-5):
            return (f(x + h) - f(x - h)) / (2 * h)
        def num_second(f, x, h=1e-5):
            return ((f(x + h) - 2 * f(x) + f(x - h)) / (h**2))
        def function(z):
            return eval(expression)
        def factorial(n):
            fact = 1
            for i in range(1, n+1):
                fact *= i
            return fact
        result = []
        if abs(denominator - x) <= r:
            if n == 0:
                result.append(0)
            if n == 1:
                result.append(complex((1j * 2 * math.pi * function(denominator))))
            if n == 2:
                result.append(complex(1j * 2 * math.pi * num_derivative(function, denominator))/factorial(n-1))
            if n == 3:
                result.append(complex(1j * 2 * math.pi * num_second(function, denominator)) / factorial(n-1))
            if n>3:
                result.append("")
        else:
            result.append("The condition |z0 - x| <= r is not satisfied.")
        return result

    #---------limit----------------------
    def lim_integer(function, approach):
        # Define basic functions needed for evaluation
        def sin(x):
            return math.sin(x)

        def tan(x):
            return math.tan(x)

        def cos(x):
            return math.cos(x)

        x = approach
        try:
            e = eval(function)
            if e == sin(x) / x and x == 0:
                lim = 1
            elif e == tan(x) / x and x == 0:
                lim = 1
            elif e == 1 / cos(x) and x == 0:
                lim = 1
            elif '/' in str(e):
                e = str(e).split('/')
                if int(e[0]) > 0 and int(e[1]) == 0:
                    lim = "limit equals infinity"
                elif int(e[0]) == 0 and int(e[1]) == 0:
                    lim = "limit does not exist"
                
            else:
                lim = e
            return lim  # Return the calculated limit instead of printing it
        except (ZeroDivisionError, ValueError):
            return "Error: Cannot evaluate the limit."
    #---------line eq---------------
    def find_line_equation(point1, point2):
        x1, y1 = point1
        x2, y2 = point2

        # Calculate slope (m)
        if x2 - x1 != 0:
            m = (y2 - y1) / (x2 - x1)
        else:
            raise ValueError("undefined slope")

        # Calculate y-intercept (b)
        b = y1 - m * x1
        return m, b
    #--------tangent------------
    def tangent_plane_equation(f, x0, y0, z0):
        def partial_derivative_x(f, x, y, z, h=1e-5):
            return (f(x + h, y, z) - f(x - h, y, z)) / (2 * h)
        def partial_derivative_y(f, x, y, z, h=1e-5):
            return (f(x, y + h, z) - f(x, y - h, z)) / (2 * h)
        def function(x, y,z):
            return eval(f)
        fx = partial_derivative_x(function, x0, y0, z0)
        fy = partial_derivative_y(function, x0, y0, z0)

        return  f' {fx} * (x - {x0}) + {fy} * (y - {y0}) - (z - {z0})=0'
    #--------(x+y)^n
    def generate_binomial_expression(coefficient_x, coefficient_y, power):
    
        try:
            # Define a function to format each term
            def format_binomial_term(term_value, term_coeffs):
                if term_value == 1:
                    term_coeffs.insert(0, "")
                else:
                    term_coeffs.insert(0, str(term_value))
                if term_coeffs[1] == "^0" and term_coeffs[2] == "^0":
                    return term_coeffs[0]
                elif term_coeffs[1] == "^0":
                    return "{}y{}".format(term_coeffs[0], term_coeffs[2])
                elif term_coeffs[2] == "^0":
                    return "{}x{}".format(term_coeffs[0], term_coeffs[1])
                elif term_coeffs[1] == "^1" and term_coeffs[2] == "^1":
                    return "{}x".format(term_coeffs[0])
                elif term_coeffs[1] == "^1":
                    return "{}x{}".format(term_coeffs[0], term_coeffs[2])
                elif term_coeffs[2] == "^1":
                    return "x{}y{}".format(term_coeffs[0], term_coeffs[1])
                return "{}x{}y{}".format(term_coeffs[0], term_coeffs[1], term_coeffs[2])

            expanded_series = []
            first_term = pow(coefficient_x, power)
            term_coeffs = ["^" + str(power), "^0"]
            expanded_series.append(f"({coefficient_x}x+{coefficient_y}y)^{power} = " + format_binomial_term(first_term, term_coeffs) + "  +  ")
            next_term = first_term
            for i in range(1, power + 1):
                next_term = int(next_term * coefficient_y * (power - i + 1) / (i * coefficient_x))
                term_coeffs = ["" if x == 1 else "^" + str(x) for x in [power - i, i]]
                if i != power:
                    expanded_series.append(format_binomial_term(next_term, term_coeffs) + "  +  ")
                else:
                    expanded_series.append(format_binomial_term(next_term, term_coeffs))
        
            # Display the result in the GUI
            return "".join(expanded_series)

        except Exception as e:
            return ("Error: Invalid input")
    #--------res-------------
    def find_residue(func, z0): #мы исправили этот код, чек res1.py
        z = sp.symbols('z')
        denominator = sp.denom(func)
        denominator_roots = [root for root in range(-10, 11) if denominator.subs(z, root) == 0]

        func_times_denom = func * denominator
        limit_expr = (z - z0) * func
        limit_value = sp.limit(limit_expr, z, z0)

        residue = limit_value

        return f"Residue at z = {z0} is: {residue}"


class App:
    def __init__(self, root):
        self.root = root
        self.root.title('Final')
        self.root.geometry('500x500')

        
        self.path = '1.jpg'
        self.img = Image.open(self.path)
        self.img = self.img.resize((500, 500))
        self.img_tk = ImageTk.PhotoImage(self.img)

        
        self.image_label = tk.Label(root, image=self.img_tk)
        self.image_label.place(relx=0.5, rely=0.5, anchor='center') 

        
        label_calculus = tk.Label(root, text='CALCULUS', font=('Cooper Black', 20), bg='white', fg='black')
        label_calculus.place(relx=0.5, rely=0.25, anchor='center')  # Adjusted the placement

        
        self.start = tk.Button(root, text='Start', font=('Cooper Black', 20), command=self.wind, bg='purple', fg='white')
        self.start.place(relx=0.5, rely=0.9, anchor='center')  # Adjusted the placement

    def wind(self):
        self.root.withdraw()
        top = tk.Toplevel(self.root)
        top.title('New Window')
        top.geometry('800x800')

        
        button_style = {'bg': 'cornflowerblue', 'fg': 'white', 'font': ('ariel', 15), 'width': 25}

        tk.Button(top, text='De Moivre s Theorem (z^n)', command=lambda: self.mz_inp(top), **button_style).grid(row=1, column=1, columnspan=3, pady=2)
        tk.Button(top, text='De Moivre s Theorem(z^1/n)', command=lambda: self.mz2_inp(top), **button_style).grid(row=2, column=1, columnspan=3, pady=2)
        tk.Button(top, text='Analytic(Cauchy-R Theorem)', command=lambda: self.analyticc(top), **button_style).grid(row=3, column=1, columnspan=3, pady=2)
        tk.Button(top, text='Harmonic check', command=lambda: self.harmonicc(top), **button_style).grid(row=4, column=1, columnspan=3, pady=2)
        tk.Button(top, text='binary to decimal', command=lambda: self.binary_d(top), **button_style).grid(row=5, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' Derivative at the point x', command=lambda: self.der_f(top), **button_style).grid(row=6, column=1, columnspan=3, pady=2)
        tk.Button(top, text='Second Derivative', command=lambda: self.der_s(top), **button_style).grid(row=7, column=1, columnspan=3, pady=2)
        tk.Button(top, text='Partial Derivative',command=lambda: self.der_par(top), **button_style).grid(row=8, column=1, columnspan=3, pady=2)
        tk.Button(top, text='Cauchy Theorem(integral).',command=lambda: self.ci(top), **button_style).grid(row=9, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' (a+b)^n',command=lambda: self.bin(top), **button_style).grid(row=10, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' Tangent plane', command=lambda: self.tan(top),**button_style).grid(row=11, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' Limit of function',command=lambda: self.lim(top), **button_style).grid(row=12, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' find line equation',command=lambda: self.lineq(top), **button_style).grid(row=13, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' Critical points', command=lambda: self.crit(top),**button_style).grid(row=14, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' GCD and LCM',command=lambda: self.g_l(top), **button_style).grid(row=15, column=1, columnspan=3, pady=2)
        tk.Button(top, text=' RES(intg)',command=lambda: self.ress(top), **button_style).grid(row=16, column=1, columnspan=3, pady=2)
        top.protocol("WM_DELETE_WINDOW", lambda: self.on_close_top(top))
    def mz_inp(self,top):
        global var1,var2,var3
        tk.Label(top,text='Enter x and y (x+iy)',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Enter degree of (x+iy), n=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        self.n_var = tk.StringVar()
        tk.Entry(top,text=self.x_var,width=5).grid(row=1, column=15, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=1, column=19, columnspan=3)
        tk.Entry(top,text=self.n_var,width=5).grid(row=2, column=15, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        
    def res(self,top):
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        n = int(self.n_var.get())
        result=Operations.complexx(x,y,n)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)

    def mz2_inp(self,top):
        tk.Label(top,text='Enter x and y (x+iy)',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Enter degree of (x+iy), n=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        self.n_var = tk.StringVar()
        tk.Entry(top,text=self.x_var,width=5).grid(row=1, column=15, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=1, column=19, columnspan=3)
        tk.Entry(top,text=self.n_var,width=5).grid(row=2, column=15, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.res_z1n(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=10, columnspan=3)
    def res_z1n(self,top):
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        n = int(self.n_var.get())
        result=Operations.sqr_complex(x,y,n)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=10, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)

    def analyticc(self,top):
        self.u_var = tk.StringVar()
        self.v_var = tk.StringVar()
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        tk.Label(top,text='Enter u function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Enter v function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Label(top,text='x=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=3, column=8, columnspan=3)
        tk.Label(top,text='y=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=3, column=15, columnspan=3)
        tk.Entry(top,text=self.u_var,width=10).grid(row=1, column=15, columnspan=3)
        tk.Entry(top,text=self.v_var,width=10).grid(row=2, column=15, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=3, column=12, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=3, column=19, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.res_analy(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def res_analy(self,top):
        u=self.u_var.get()
        v=self.v_var.get()
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.analytic(u,v,x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=16, columnspan=3)
    def harmonicc(self,top):
        n = simpledialog.askinteger("Input", "your function? (1.u or 2.v)")
        if n==1:
            self.u_var = tk.StringVar()
            self.x_var = tk.StringVar()
            self.y_var = tk.StringVar()
            tk.Label(top,text='Enter u function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
            tk.Entry(top,text=self.u_var,width=10).grid(row=1, column=15, columnspan=3)
            tk.Entry(top,text=self.x_var,width=5).grid(row=3, column=12, columnspan=3)
            tk.Entry(top,text=self.y_var,width=5).grid(row=3, column=19, columnspan=3)
       
            sbmt=tk.Button(top,text='Submit',command=lambda: self.u_fun(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        elif n==2:
            self.v_var = tk.StringVar()
            self.x_var = tk.StringVar()
            self.y_var = tk.StringVar()
            tk.Label(top,text='Enter v function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
            tk.Entry(top,text=self.u_var,width=10).grid(row=1, column=15, columnspan=3)
            tk.Entry(top,text=self.x_var,width=5).grid(row=3, column=12, columnspan=3)
            tk.Entry(top,text=self.y_var,width=5).grid(row=3, column=19, columnspan=3)
            sbmt=tk.Button(top,text='Submit',command=lambda: self.v_fun(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def u_fun(self,top):
        u=self.u_var.get()
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.is_harmonic_u(u,x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=16, columnspan=3)
    def v_fun(self,top):
        v=self.v_var.get()
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.is_harmonic_u(v,x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    def der_f(self,top):
        tk.Label(top,text='Enter your function',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Enter x value:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        self.x_var = tk.StringVar()
        self.f_var = tk.StringVar()
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=15, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.der_f_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def der_f_res(self,top):
        f=self.f_var.get()
        x = int(self.x_var.get())
        result=Operations.numerical(f,x)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=8, columnspan=3)
    def der_s(self,top):
        tk.Label(top,text='Enter your function',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Enter x value:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        self.x_var = tk.StringVar()
        self.f_var = tk.StringVar()
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=15, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.der_s_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def der_s_res(self,top):
        f=self.f_var.get()
        x = int(self.x_var.get())
        result=Operations.numerical_sec(f,x)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=8, columnspan=3)
    def der_par(self,top):
        n = simpledialog.askinteger("Input", "partial derivative with recpect to (1.x or 2.y)")
        if n==1:
            self.f_var = tk.StringVar()
            self.x_var = tk.StringVar()
            self.y_var = tk.StringVar()
            
            tk.Label(top,text='Enter function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
            tk.Label(top,text='x=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
            tk.Label(top,text='y=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=15, columnspan=3)
            tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=15, columnspan=3)
            tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
            tk.Entry(top,text=self.y_var,width=5).grid(row=2, column=19, columnspan=3)
       
            sbmt=tk.Button(top,text='Submit',command=lambda: self.f_fun_x(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        elif n==2:
            self.f_var = tk.StringVar()
            self.x_var = tk.StringVar()
            self.y_var = tk.StringVar()
            tk.Label(top,text='Enter function:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
            tk.Label(top,text='x=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
            tk.Label(top,text='y=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=15, columnspan=3)
            tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=15, columnspan=3)
            tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
            tk.Entry(top,text=self.y_var,width=5).grid(row=2, column=19, columnspan=3)
            sbmt=tk.Button(top,text='Submit',command=lambda: self.f_fun_y(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def f_fun_x(self,top):
        f=self.f_var.get()
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.f_x(f,x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=16, columnspan=3)
    def f_fun_y(self,top):
        f=self.f_var.get()
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.is_harmonic_u(f,x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    def crit(self,top):
        tk.Label(top,text='Enter your function',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        self.f_var = tk.StringVar()
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=15, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.crit_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def crit_res(self,top):
        f=self.f_var.get()
        result=Operations.critical_points(f)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=8, columnspan=3)
    def g_l(self,top):
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        tk.Label(top,text='x=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='y=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=2, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.g_l_s(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def g_l_s(self,top):
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        result=Operations.gcd_lcm(x,y)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    
    def lim(self,top):
        self.f_var = tk.StringVar()
        self.x_var = tk.StringVar()
        tk.Label(top,text='function f(x)=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='x=:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.lim_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def lim_res(self,top):
        f= (self.f_var.get())
        x = int(self.x_var.get())
        result=Operations.lim_integer(f,x)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    def lineq(self,top):
        self.x1_var = tk.StringVar()
        self.x2_var = tk.StringVar()
        self.y1_var = tk.StringVar()
        self.y2_var = tk.StringVar()
        tk.Label(top,text='Point 1: x and y',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='Point 2:x2 and y2',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Entry(top,text=self.x1_var,width=5).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.y1_var,width=5).grid(row=1, column=17, columnspan=3)
        tk.Entry(top,text=self.x2_var,width=5).grid(row=2, column=12, columnspan=3)
        tk.Entry(top,text=self.y2_var,width=5).grid(row=2, column=17, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.lineq_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def lineq_res(self,top):
        x1 = int(self.x1_var.get())
        y1 = int(self.y1_var.get())
        x2 = int(self.x2_var.get())
        y2 = int(self.y2_var.get())
        point1=(x1,y1)
        point2=(x2,y2)
        result=Operations.find_line_equation(point1,point2)
        tk.Label(top,text='Result',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    def tan(self,top):
        self.f_var = tk.StringVar()
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        self.z_var = tk.StringVar()
        tk.Label(top,text='f(x,y,z)=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='points: x,y,z',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=2, column=12, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=2, column=17, columnspan=3)
        tk.Entry(top,text=self.z_var,width=5).grid(row=2, column=21, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.tan_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def tan_res(self,top):
        f= (self.f_var.get())
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        z = int(self.z_var.get())
        result=Operations.tangent_plane_equation(f,x,y,z)
        tk.Label(top,text='Result:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=10, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    


    
    def binary_d(self, top):
        tk.Label(top, text='Enter your binary number:', bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8,
                                                                                                      columnspan=3)
        self.num = tk.StringVar()
        tk.Entry(top, textvariable=self.num, width=20, borderwidth=5, bg='gray64', fg='black').grid(row=1, column=13, columnspan=3)
        result_button = tk.Button(top, text='Submit:', **{'font': ('ariel', 10), 'bg': 'cornflowerblue', 'fg': 'white', 'width': 20},
                                  command=lambda: self.display_result(top, 'Binary to Decimal Result', self.binary_to_decimal))
        result_button.grid(row=5, column=14, columnspan=3)

    def display_result(self, top, label_text, calculation_func):
        input_value = self.num.get()
        try:
            input_value = int(input_value)
            result_label_text = f'{label_text}: {calculation_func(input_value)}'
        except ValueError:
            result_label_text = f'{label_text}: Invalid input (not an integer)'

        tk.Label(top, text=result_label_text, font=('Arial', 12), bg='cornflowerblue', fg='white', pady = 10).grid(row=3, column=10, columnspan=3)

    def on_close_top(self, top):
        top.destroy()
        self.root.deiconify()

    def binary_to_decimal(self, binary_str):
        decimal = 0
        binary_str = str(binary_str)[::-1]

        for i in range(len(binary_str)):
            if binary_str[i] == '1':
                decimal += 2 ** i

        return decimal
    def ci(self,top):
        self.f_var = tk.StringVar()
        self.z0_var = tk.StringVar()
        self.r_var = tk.StringVar()
        self.x_var = tk.StringVar()
        self.n_var = tk.StringVar()
        tk.Label(top,text='f(z)=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='z0=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Label(top,text='radius=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=3, column=8, columnspan=3)
        tk.Label(top,text='C:(z-x)=>x=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=4, column=8, columnspan=3)
        tk.Label(top,text='degree=> n=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=8, columnspan=3)
        
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.z0_var,width=5).grid(row=2, column=12, columnspan=3)
        tk.Entry(top,text=self.r_var,width=5).grid(row=3, column=12, columnspan=3)
        tk.Entry(top,text=self.x_var,width=5).grid(row=4, column=12, columnspan=3)
        tk.Entry(top,text=self.n_var,width=5).grid(row=5, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.ci_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def ci_res(self,top):
        f= (self.f_var.get())
        z0 = int(self.z0_var.get())
        r = int(self.r_var.get())
        x = int(self.x_var.get())
        n = int(self.n_var.get())
        result=Operations.cauchy_intg(f,z0,r,x,n)
        tk.Label(top,text='Result:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=7, column=10, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=9, column=10, columnspan=3)
    def bin(self,top):
        self.x_var = tk.StringVar()
        self.y_var = tk.StringVar()
        self.n_var = tk.StringVar()
        tk.Entry(top,text=self.x_var,width=5).grid(row=1, column=12, columnspan=3)
        tk.Entry(top,text=self.y_var,width=5).grid(row=2, column=12, columnspan=3)
        tk.Entry(top,text=self.n_var,width=5).grid(row=3, column=12, columnspan=3)
        
        tk.Label(top,text='x=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='y=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Label(top,text='n=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=3, column=8, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.bin_res(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def bin_res(self,top):
        x = int(self.x_var.get())
        y = int(self.y_var.get())
        n = int(self.n_var.get())
        result=Operations.generate_binomial_expression(x,y,n)
        tk.Label(top,text='Result:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=7, column=10, columnspan=3)
        tk.Label(top,text=result,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=9, column=10, columnspan=3)
    def ress(self,top):
        self.f_var = tk.StringVar()
        self.z0_var = tk.StringVar()
        
        tk.Label(top,text='f(z)=',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=1, column=8, columnspan=3)
        tk.Label(top,text='points: z0=>',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=2, column=8, columnspan=3)
        tk.Entry(top,text=self.f_var,width=10).grid(row=1, column=12, columnspan=3)
        
        tk.Entry(top,text=self.z0_var,width=5).grid(row=2, column=12, columnspan=3)
        sbmt=tk.Button(top,text='Submit',command=lambda: self.calculate_residue(top),bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=16, columnspan=3)
    def calculate_residue(self,top):
        f= (self.f_var.get())
        z0 = int(self.z0_var.get())

        try:
           func_expr = eval(f, {'z': sp.symbols('z')})
           z0_value = int(z0)

           residue = Operations.find_residue(func_expr, z0_value)
           
           tk.Label(top,text='Result:',bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=5, column=10, columnspan=3)
           tk.Label(top,text=residue,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    

        except Exception as e:
           texxt=f"Error: {e}"
           tk.Label(top,text=texxt,bg='cornflowerblue', fg='white', font=('Ariel', 15)).grid(row=6, column=10, columnspan=3)
    
           
    
    

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
