from bika_final import *
from dasha_final import *
from anelya_final import *

first_derivative_tests()

print("\n")

second_derivative_tests()

print("\n")

#lineintegral test
def x(t):
  return 1-t
def y(t):
  return 2-3*t
def z(t):
  return 3-2*t
def f(x,y,z):
  return (x+y**2-z-4)
print(lineintegral(x,y,z,f))

print("\n")

#tangentplane test
def funct(x,y):
  return 32-3*x**2-4*y**2
TangentPlane(funct)

#answer should be 112
lim_integer("x**2+4*(x+1)**3",2)
print("\n")

lim_graph("cos(2*x)+4*x","+inf")
#answer should be +inf
print("\n")

derivative_poly("xmod**2+4*(xmod+1)**3")
#answer should be 2xmod+12(xmod+1)**2
print("\n")

expand_(1,1,3)
#answer should be xmod**3+3*x**2*xmod+3*xmod**2*x+x**3
print("\n")

gradient("x**2+y**3+4*z")
#answer should be 2*x+3*y**2+4
print("\n")

conservativnes("x**2i+y**3j+4*zk")
#answer should be conservative
print("\n")



P1 = [6, -29, 27, 27, -29, 6]
ruffini_test(P1)

print("\n")

S = [2, 3, 5, 2, 3, 12, 5, 3, 4]
test(S)

print("\n")

H = [1, 1, -11, -5, 30]

factor_poly(H, 4)

print(leyland_primes_oeis(1000))

