
import sympy
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
import numpy as np
from numpy import*
from sympy import*
#from sympy.functions.elementary.trigonometric import TrigonometricFunction
x=symbols('x')
xmod=symbols('xmod')


def my_float(s):
    constants = {"pi": 3.14159, "e": 2.71928}
    if s in constants:
        return constants[s]
    elif '/' in s:
        values = s.split('/')
        i=values[0]
        i2=float(values[1])
        if i in constants:
            i=constants[i]
            s=i/i2
            return float(s) 

    else:
        return float(s)
# find limit of function as variable approaches to some integer        
def lim_integer(function,approach):
    x=symbols('x')
    xmod=symbols('xmod')
    x=approach
    e = eval(function)
    if (e==sin(x)/x and x==0) or (e==tan(x)/x and x==0) or (e==1/cos(x) and x==0 ):
        lim=1
        #print(e)
    elif '/' in str(e):
        e=str(e).split('/')
        for i in e:
        
            if int(e[0])>0 and int(e[1])==0:
                lim="limit equals infinity"
            elif int(e[0])==0 and int(e[1])==0:
                lim="limit does not exist"
            else:
                e="/".join(reversed(str(e).split('/')))
                lim=eval(e)
                
            

    else:
        lim=e
    print(lim)
        #print(e)

# find limit as variable approaches to infinity by graphing methodd

def lim_graph(function,approach):

    if approach.isdigit():
        n=int(approach)
        x=np.linspace(-20,20,40)
        y=eval(function)
        for i in x:
                if round(i)==n:
                    x=round(i)
                    lim=eval(function)
        plt.plot(x,y)
        plt.xticks(np.arange(min(x), max(x)+1, 1.0))
        #plt.show()


    else:
        trigonometric=["sin","cos","tan","cot","sec","csc"]
        match=[]
    #if any(func in function for func in trigonometric) :
        for func in trigonometric:
            if func in function:
                match.append(func)
                if len(match)<function.count('x'):
                    if "csc" in function:
                        function=function.replace("csc(x)","1/sin(x)")
                        x=np.linspace(-20,20,200)
                        y=eval(function)

                        if approach=="+inf":
                                if y[-2]>y[-1]:
                                    lim=math.floor(y[-1])
                                    #print(lim)
                                elif y[-2]<y[-1]:
                                    lim="+inf"
                                    #print(lim)
                        elif approach=="-inf":
                                if y[1]>y[0]:
                                    lim="-inf"
                                    #print(lim)
                                elif y[1]<y[0]:
                                    lim=math.ceil(y[0])
                                    #print(lim)
                        plt.plot(x,y)
                        #plt.show()
                    else:
                        x=np.linspace(-20,20,200)
                        y=eval(function)

                        if approach=="+inf":
                                if y[-2]>y[-1]:
                                    lim=math.floor(y[-1])
                                    print(lim)
                                elif y[-2]<y[-1]:
                                    lim="+inf"
                                    #print(lim)
                        elif approach=="-inf":
                                if y[1]>y[0]:
                                    lim="-inf"
                                # print(lim)
                                elif y[1]<y[0]:
                                    lim=math.ceil(y[0])
                                    #print(lim)
                        plt.plot(x,y)
                        #plt.show()
                elif len(match)==function.count('x'):
                    lim="undefined"
                    #print(lim)
            else:
                x=np.linspace(-20,20,200)
                y=eval(function)

                if approach=="+inf":
                        if y[-2]>y[-1]:
                            lim=math.floor(y[-1])
                            #print(lim)
                        elif y[-2]<y[-1]:
                            lim="+inf"
                            #print(lim)
                elif approach=="-inf":
                        if y[1]>y[0]:
                            lim="-inf"
                            #print(lim)
                        elif y[1]<y[0]:
                            lim=math.ceil(y[0])
                            #print(lim)
                plt.plot(x,y)
                #plt.show()
    print(lim)

"""
    if any(func in function for func in trigonometric ):
        if '+' in function:
            function1=function.split('+',1)[0]
            #print(function1)
            function2=function[function.rfind('+'):]
            #print(function2)
            if any(func in function1 for func in trigonometric ) and any(func in function2 for func in trigonometric ):
                lim="undefined"
                print(lim)
            elif ((any(func in function1 for func in trigonometric ) and (any(func in function2 for func in trigonometric )==False and 'x' in function2))) or ((any(func in function2 for func in trigonometric )) and (any(func in function1 for func in trigonometric )==False and 'x' in function1 )) :
                if "csc" in function1 or "csc" in function2:
                    function=function.replace("csc(x)","1/sin(x)")
                    x=np.linspace(-20,20,200)
                    y=eval(function)

                    if approach=="+inf":
                            if y[-2]>y[-1]:
                                lim=math.floor(y[-1])
                                print(lim)
                            elif y[-2]<y[-1]:
                                lim="+inf"
                                print(lim)
                    elif approach=="-inf":
                            if y[1]>y[0]:
                                lim="-inf"
                                print(lim)
                            elif y[1]<y[0]:
                                lim=math.ceil(y[0])
                                print(lim)
                    plt.plot(x,y)
                    #plt.show()
                else:
                    x=np.linspace(-20,20,200)
                    y=eval(function)

                    if approach=="+inf":
                            if y[-2]>y[-1]:
                                lim=math.floor(y[-1])
                                print(lim)
                            elif y[-2]<y[-1]:
                                lim="+inf"
                                print(lim)
                    elif approach=="-inf":
                            if y[1]>y[0]:
                                lim="-inf"
                                print(lim)
                            elif y[1]<y[0]:
                                lim=math.ceil(y[0])
                                print(lim)
                    plt.plot(x,y)
                    #plt.show()


            #else:
                    #lim="undefined"
                    #print(lim)
        elif '-' in function:
            function1=function.split('-',1)[0]
            function2=function[function.rfind('-'):]
            if any(func in function1 for func in trigonometric ) and any(func in function2 for func in trigonometric ):
                lim="undefined"
                print(lim)
            elif (any(func in function1 for func in trigonometric ) and (any(func in function2 for func in trigonometric )==False and 'x' in function2)) or (any(func in function2 for func in trigonometric )) and (any(func in function1 for func in trigonometric )==False and 'x' in function1 ) :
                if "csc" in function1 or "csc" in function2:
                    function=function.replace("csc(x)","1/sin(x)")
                    x=np.linspace(-20,20,200)
                    y=eval(function)

                    if approach=="+inf":
                            if y[-2]>y[-1]:
                                lim=math.floor(y[-1])
                                print(lim)
                            elif y[-2]<y[-1]:
                                lim="+inf"
                                print(lim)
                    elif approach=="-inf":
                            if y[1]>y[0]:
                                lim="-inf"
                                print(lim)
                            elif y[1]<y[0]:
                                lim=math.ceil(y[0])
                                print(lim)
                    plt.plot(x,y)
                    #plt.show()
                else:
                    x=np.linspace(-20,20,200)
                    y=eval(function)

                    if approach=="+inf":
                            if y[-2]>y[-1]:
                                lim=math.floor(y[-1])
                                print(lim)
                            elif y[-2]<y[-1]:
                                lim="+inf"
                                print(lim)
                    elif approach=="-inf":
                            if y[1]>y[0]:
                                lim="-inf"
                                print(lim)
                            elif y[1]<y[0]:
                                lim=math.ceil(y[0])
                                print(lim)
                    plt.plot(x,y)
                    #plt.show()


        else:
                    lim="undefined"
                    print(lim)

    else:

        x=np.linspace(-20,20,200)
        y=eval(function)

        if approach=="+inf":
                if y[-2]>y[-1]:
                    lim=math.floor(y[-1])
                    print(lim)
                elif y[-2]<y[-1]:
                    lim="+inf"
                    print(lim)
        elif approach=="-inf":
                if y[1]>y[0]:
                    lim="-inf"
                    print(lim)
                elif y[1]<y[0]:
                    lim=math.ceil(y[0])
                    print(lim)
        #print(len(y))
        #plt.xticks(np.arange(min(x), max(x)+1, 1.0))
        plt.plot(x,y)
        plt.show()
"""




#solves binamoal expression such as (a+b)^n=
def expand_(co_a, co_b, n):
    def formatting(next_term, coeffs):
        if next_term == 1:
            coeffs.insert(0, "")
        else:
            coeffs.insert(0, next_term)
        if coeffs[1] == "^0" and coeffs[2] == "^0":
            return coeffs[0]
        elif coeffs[1] == "^0":
            return "{}x{}".format(coeffs[0], coeffs[2])
        elif coeffs[2] == "^0":
            return "{}xmod{}".format(coeffs[0], coeffs[1])
        elif coeffs[1] == "^1" and coeffs[2] == "^1":
            return "{}xmodx".format(coeffs[0])
        elif coeffs[1] == "^1":
            return "{}xmodx{}".format(coeffs[0], coeffs[2])
        elif coeffs[2] == "^1":
            return "xmod{}x".format(coeffs[0], coeffs[1])
        return "{}xmod{}x{}".format(coeffs[0], coeffs[1], coeffs[2])
    series = list()
    first_term = pow(co_a, n)
    coeffs = ["^" + str(n), "^0"]
    series.append(formatting(first_term, coeffs) + "  +  ")
    next_term = first_term
    for i in range(1, n + 1):
        next_term = int(next_term * co_b * (n - i + 1) / (i * co_a))
        coeffs = ["" if x == 1 else "^" + str(x) for x in [n - i, i]]
        if i != n:
            series.append(formatting(next_term, coeffs) + "  +  ")
        else:
            series.append(formatting(next_term, coeffs))
    print("".join(series))
    

#finds derivative of any polinom with one variable(x)
def derivative_poly(function):
    x=symbols('x')
    xmod=symbols('xmod')
    function_new=function.replace("xmod","(xmod+x)")
    #print(function_new)

    if "(xmod+x)**2" in function_new:
        sqr="(xmod**2+2*x*xmod+x*x)"
        function_new=function_new.replace("(xmod+x)**2",sqr)
    if "(xmod+x)**3" in function_new:
        sqr="(xmod**3+3*x**2*xmod+3*xmod**2*x+x**3)"
        function_new=function_new.replace("(xmod+x)**2",sqr)
    
    
    power_red="(xmod+x)**"
    if (power_red in function_new)  and function_new[-1].isdigit()==True and int(function_new[-1])>3:
        function_new=expand(eval(function_new))

    ff=(eval(function_new)-eval(function))/x

    if str(ff).count('x')>1:
        ff=factor(ff)
        if str(x) in str(ff):
            drv=lim_integer(str(ff),0)
        return drv
        
        #print(ff)
    
    elif str(x) in str(ff):
        drv=lim_integer(str(ff),0)
    #print(ff)
        return drv
    else:
        print(ff)
    








