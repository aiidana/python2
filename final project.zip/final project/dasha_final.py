import gmpy2
from gmpy2 import mpz
from math import *
import math
#from itertools import zip_longest

#FACTORIZATION OF A POLYNOMIAL
def sanitize(s):
    return (
        s.replace(" 0x^1 ", " ")
        .replace("+ -", "- ")
        .replace("1x", "x")
        .replace(" + - ", " - ")
        .replace("^1", "")
    )


def factors(n):
    result = []
    n = mpz(n)
    for i in range(1, gmpy2.isqrt(n) + 1):
        div, mod = divmod(n, i)
        if not mod:
            result.append(i)
    return result


def poly_synthetic_div(P, Q):
    lP = len(P)
    R = [0] * lP

    for i in range(0, lP):
        if i == 0:
            R[i] = P[i]
        else:
            R[i] = P[i] + Q * R[i - 1]
    return R


def get_rationals(poly, grade):
    tmp = []
    lP = len(poly)
    d = factors(abs(poly[-1]))
    if d == []:
        d = [abs(poly[-1])]
    n = factors(abs(grade - poly[0]))
    if n == []:
        n = [abs(poly[0])]
    # print d
    # print n
    for d_ in d:
        for n_ in n:
            div = float(d_) / n_
            if div > 0:
                tmp.append(div)
    tmp2 = []
    for r in set(sorted(tmp)):
        tmp2.append(r)
        tmp2.append(-r)
    return tmp2


def poly_to_text(poly, grade=0):
    lP = len(poly)
    tmp = []
    for i in range(0, lP):
        if grade - i > -1:
            if grade - i == 0:
                tmp.append("%d" % poly[i])
            else:
                tmp.append("%dx^%d" % (poly[i], grade - i))

    return sanitize(" + ".join(tmp))


def poly_synthetic_div_complete_step(poly, grade):
    print ("-" * 60)
    print ("Grade:", grade)
    print ("P = ", poly_to_text(poly, grade))
    print ("Coefs: P =", poly)
    rationals = get_rationals(poly, grade)
    print ("rationals:", rationals)
    term = []
    if len(rationals) > 0:
        for Q in rationals:
            R = poly_synthetic_div(poly, Q)
            if R[-1] == 0:
                print ("Q =", Q)
                print ("%d is divisor" % Q)
                print ("Coefs: R =", R)
                print ("R = ", poly_to_text(R, grade - 1))
            if R[-1] == 0:
                term = ["(x + %d)" % -Q]
                # break
                return R[:-1], term
        print ("No divisor found")
        return None
    else:
        print ("No rationals")
    return None


def factor_poly(Poly, Grade):
    P = Poly
    terms = []
    for grade in range(Grade, 1, -1):
        result = poly_synthetic_div_complete_step(P, grade)
        if result != None:
            P, term = result
            terms += term
        else:
            break
    terms += ["(%s)" % poly_to_text(P, grade)]
    print ("=" * 60)
    s = sanitize("".join(terms))
    print ("Result:", s)


#RUFFINI METHOD 
# tells if a n is prime or not
def isPrime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False

    return True


# finds the prime factors of n
def factors(n):
    factor = []
    limit = int(round(sqrt(n), 2)) + 1
    check = 2
    num = n
    if isPrime(n):
        return [n]
    for check in range(2, limit):
        if isPrime(check) and (num % check) == 0:
            factor.append(check)
            num /= check
            if isPrime(num):
                factor.append(num)
                break
    factor = sorted(factor)
    return factor


# add the negative factors to try
def addnegatives(D):
    nD = []
    for i in D:
        nD.append(-abs(i))
        nD.append(abs(i))
    return nD


# one step ruffini
def ruffini_step(P, D):

    for i in range(len(D)):
        tmpPoli = []
        for j in range(len(P)):
            if j == 0:
                tmpPoli.append(P[j])
            else:
                tmpPoli.append(P[j] + (D[i] * tmpPoli[j - 1]))
        if tmpPoli[len(tmpPoli) - 1] == 0:
            return [D[i], tmpPoli]


def ruffini_test(P):
    print ("P=", P)
    TI = P[len(P) - 1]
    D = [1] + factors(abs(TI)) + [abs(TI)]
    D = addnegatives(D)
    D.sort()

    tmp = P
    for k in range(len(P) - 3):
        ret = ruffini_step(tmp, D)
        tmp = ret[1]
        print ("Grade=", len(P) - k, "root=", ret[0], "coefs=", ret[1])


#Analys of series

def mean(L):
    """mean or average of all values in list"""

    tmp = sum(L) * 1.0
    l = len(L)
    return tmp / l


avg = mean


def stddev(X):
    """standar deviation calculaion of all values in the list"""

    l = len(X)

    def F(X):
        x = mean(X)
        s = 0
        for i in range(0, l):
            s += (X[i] - x) ** 2
        return s

    return math.sqrt((1.0 / l) * F(X))


def MAD(X):
    """Median Absolute deviation calculaion of all values in the list"""

    l = len(X)

    def F(X):
        x = mean(X)
        s = 0
        for i in range(0, l):
            s += abs(X[i] - x)
        return s

    return (1.0 / l) * F(X)


def bounds(X):
    """Upper and lower bounds"""

    SD = stddev(X)
    m = mean(X)
    return m - SD, SD + m


def simple_anonaly_detection(X):
    """A simple check if a value in a list is outside the bounds
    It should return tuples of (index,value)"""

    B = bounds(X)
    for i in range(0, len(X)):
        if X[i] < B[0] or X[i] > B[1]:
            yield (i, X[i])



def test(S):
    """
    Expected output:
    Series: [2, 3, 5, 2, 3, 12, 5, 3, 4]
    Mean: 4.333333333333333
    StdDev: 2.9059326290271157
    Bounds: (1.4274007043062173, 7.239265962360449)
    simple anomaly detection: [(5, 12)]
    """
   
    print("Series:", S)
    print("Mean:", mean(S))
    print("StdDev:", stddev(S))
    print("Bounds:", bounds(S))
    print("simple anomaly detection:", list(simple_anonaly_detection(S)))




#LEYLAND PRIMES
def leyland_primes_naive(m):
    tmp = []
    for i in range(2, m):
        for j in range(2, m):
            x = i ** j + j ** i
            if gmpy2.is_prime(x):
                if x not in tmp:
                    tmp.append(x)
    return tmp


def leyland_primes_oeis(N):
    tmp = [3]
    n = 2
    n = 1
    n1 = 1
    while n < N:
        n = 2 * n1 ** n1
        k = n1 + 1
        while k < N:
            if gmpy2.gcd(n, k) == 1:
                a = n ** k + k ** n
                if a > N:
                    break
                if gmpy2.is_prime(a):
                    if a not in tmp:
                        tmp.append(a)
                        print(a)
            k += 1
        n1 += 1
    return tmp

    






