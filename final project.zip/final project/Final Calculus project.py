import sympy
import math
import matplotlib.pyplot as plt
from matplotlib.pyplot import*
import numpy as np
from numpy import*
from sympy import*
import gmpy2
from gmpy2 import mpz
from math import *

#from sympy.functions.elementary.trigonometric import TrigonometricFunction
x=symbols('x')
xmod=symbols('xmod')


def my_float(s):
    constants = {"pi": 3.14159, "e": 2.71928}
    if s in constants:
        return constants[s]
    elif '/' in s:
        values = s.split('/')
        i=values[0]
        i2=float(values[1])
        if i in constants:
            i=constants[i]
            s=i/i2
            return float(s) 

    else:
        return float(s)
# find limit of function as variable approaches to some integer        
def lim_integer(function,approach):
    x=symbols('x')
    xmod=symbols('xmod')
    x=approach
    e = eval(function)
    if (e==sin(x)/x and x==0) or (e==tan(x)/x and x==0) or (e==1/cos(x) and x==0 ):
        lim=1
        #print(e)
    elif '/' in str(e):
        e=str(e).split('/')
        for i in e:
        
            if int(e[0])>0 and int(e[1])==0:
                lim="limit equals infinity"
            elif int(e[0])==0 and int(e[1])==0:
                lim="limit does not exist"
            else:
                e="/".join(reversed(str(e).split('/')))
                lim=eval(e)
                
            

    else:
        lim=e
    print(lim)
        #print(e)

# find limit as variable approaches to infinity by graphing methodd

def lim_graph(function,approach):

    if approach.isdigit():
        n=int(approach)
        x=np.linspace(-20,20,40)
        y=eval(function)
        for i in x:
                if round(i)==n:
                    x=round(i)
                    lim=eval(function)
        plt.plot(x,y)
        plt.xticks(np.arange(min(x), max(x)+1, 1.0))
        #plt.show()


    else:
        trigonometric=["sin","cos","tan","cot","sec","csc"]
        match=[]
    #if any(func in function for func in trigonometric) :
        for func in trigonometric:
            if func in function:
                match.append(func)
                if len(match)<function.count('x'):
                    if "csc" in function:
                        function=function.replace("csc(x)","1/sin(x)")
                        x=np.linspace(-20,20,200)
                        y=eval(function)

                        if approach=="+inf":
                                if y[-2]>y[-1]:
                                    lim=math.floor(y[-1])
                                    #print(lim)
                                elif y[-2]<y[-1]:
                                    lim="+inf"
                                    #print(lim)
                        elif approach=="-inf":
                                if y[1]>y[0]:
                                    lim="-inf"
                                    #print(lim)
                                elif y[1]<y[0]:
                                    lim=math.ceil(y[0])
                                    #print(lim)
                        plt.plot(x,y)
                        #plt.show()
                    else:
                        x=np.linspace(-20,20,200)
                        y=eval(function)

                        if approach=="+inf":
                                if y[-2]>y[-1]:
                                    lim=math.floor(y[-1])
                                    print(lim)
                                elif y[-2]<y[-1]:
                                    lim="+inf"
                                    #print(lim)
                        elif approach=="-inf":
                                if y[1]>y[0]:
                                    lim="-inf"
                                # print(lim)
                                elif y[1]<y[0]:
                                    lim=math.ceil(y[0])
                                    #print(lim)
                        plt.plot(x,y)
                        #plt.show()
                elif len(match)==function.count('x'):
                    lim="undefined"
                    #print(lim)
            else:
                x=np.linspace(-20,20,200)
                y=eval(function)

                if approach=="+inf":
                        if y[-2]>y[-1]:
                            lim=math.floor(y[-1])
                            #print(lim)
                        elif y[-2]<y[-1]:
                            lim="+inf"
                            #print(lim)
                elif approach=="-inf":
                        if y[1]>y[0]:
                            lim="-inf"
                            #print(lim)
                        elif y[1]<y[0]:
                            lim=math.ceil(y[0])
                            #print(lim)
                plt.plot(x,y)
                #plt.show()
    print(lim)




#solves binamoal expression such as (a+b)^n=
def expand_(co_a, co_b, n):
    def formatting(next_term, coeffs):
        if next_term == 1:
            coeffs.insert(0, "")
        else:
            coeffs.insert(0, next_term)
        if coeffs[1] == "^0" and coeffs[2] == "^0":
            return coeffs[0]
        elif coeffs[1] == "^0":
            return "{}x{}".format(coeffs[0], coeffs[2])
        elif coeffs[2] == "^0":
            return "{}xmod{}".format(coeffs[0], coeffs[1])
        elif coeffs[1] == "^1" and coeffs[2] == "^1":
            return "{}xmodx".format(coeffs[0])
        elif coeffs[1] == "^1":
            return "{}xmodx{}".format(coeffs[0], coeffs[2])
        elif coeffs[2] == "^1":
            return "xmod{}x".format(coeffs[0], coeffs[1])
        return "{}xmod{}x{}".format(coeffs[0], coeffs[1], coeffs[2])
    series = list()
    first_term = pow(co_a, n)
    coeffs = ["^" + str(n), "^0"]
    series.append(formatting(first_term, coeffs) + "  +  ")
    next_term = first_term
    for i in range(1, n + 1):
        next_term = int(next_term * co_b * (n - i + 1) / (i * co_a))
        coeffs = ["" if x == 1 else "^" + str(x) for x in [n - i, i]]
        if i != n:
            series.append(formatting(next_term, coeffs) + "  +  ")
        else:
            series.append(formatting(next_term, coeffs))
    print("".join(series))
    

#finds derivative of any polinom with one variable(x)
def derivative_poly(function):
    x=symbols('x')
    xmod=symbols('xmod')
    function_new=function.replace("xmod","(xmod+x)")
    #print(function_new)

    if "(xmod+x)**2" in function_new:
        sqr="(xmod**2+2*x*xmod+x*x)"
        function_new=function_new.replace("(xmod+x)**2",sqr)
    if "(xmod+x)**3" in function_new:
        sqr="(xmod**3+3*x**2*xmod+3*xmod**2*x+x**3)"
        function_new=function_new.replace("(xmod+x)**2",sqr)
    
    
    power_red="(xmod+x)**"
    if (power_red in function_new)  and function_new[-1].isdigit()==True and int(function_new[-1])>3:
        function_new=expand(eval(function_new))

    ff=(eval(function_new)-eval(function))/x

    if str(ff).count('x')>1:
        ff=factor(ff)
        if str(x) in str(ff):
            drv=lim_integer(str(ff),0)
        return drv
        
        #print(ff)
    
    elif str(x) in str(ff):
        drv=lim_integer(str(ff),0)
    #print(ff)
        return drv
    else:
        print(ff)
# find the gradient of function which is grad f= df/dx + df/dy + df/dz
def gradient(function):
    x=symbols('x')
    y=symbols('y')
    z=symbols('z')
    h=symbols('h')
    h = 1e-5
    global dfx,dfy,dfz
    def dfx(function):
            x=symbols('x')
            y=symbols('y')
            z=symbols('z')
            f_x=function.replace("x","(x+h)")
            power_red="(x+h)**"
            if (power_red in f_x):
                #i=f_x.find(power_red)+1
                for i in range(len(f_x)):
                    if f_x[i]==')' and f_x[i+2]=='*' and f_x[i+3].isdigit():
                        f_x=str(expand(eval(f_x)))
                        df_x=factor((eval(f_x)-eval(function))/h)
            else:
                df_x=factor((eval(f_x)-eval(function))/h)
            print(df_x)
            return df_x
    def dfy(function):
            x=symbols('x')
            y=symbols('y')
            z=symbols('z')
            f_y=function.replace("y","(y+h)")
            power_red="(y+h)**"
            if (power_red in f_y):
                for i in range(len(f_y)):
                    if f_y[i]==')' and f_y[i+2]=='*' and f_y[i+3].isdigit():
                        f_y=str(expand(eval(f_y)))
                        df_y=factor((eval(f_y)-eval(function))/h)
            else:
                df_y=factor((eval(f_y)-eval(function))/h)
            print(df_y)
            return df_y
    def dfz(function):
            x=symbols('x')
            y=symbols('y')
            z=symbols('z')
            f_z=function.replace("z","(z+h)")
            power_red="(z+h)**"
            if (power_red in f_z):
                for i in range(len(f_z)):
                    if f_z[i]==')' and f_z[i+2]=='*' and f_z[i+3].isdigit():
                        f_z=str(expand(eval(f_z)))
                        df_z=factor((eval(f_z)-eval(function))/h)
            else:
                df_z=factor((eval(f_z)-eval(function))/h)
            print(df_z)
            return df_z
    dfx(function)
    dfy(function)
    dfz(function)
    grad= dfx(function)+dfy(function)+dfz(function)
    print(grad)
    return 
def conservativnes(function):
    i=symbols('i')
    j=symbols('j')
    k=symbols('k')
    m=function.split('i', 1)[0]
    n=function.split('j', 1)[0]
    if m in n:
        n=n.replace(m,"")
    p=function.replace(m,"")
    #gradient(m)
    #gradient(n)
    #gradient(p)
    if dfx(n)== dfy(m) and dfz(m)==dfx(p) and dfz(n)==dfy(p):
        print("field is conservative")
    else:
        print("field is not conservative")





#FACTORIZATION OF A POLYNOMIAL
def sanitize(s):
    return (
        s.replace(" 0x^1 ", " ")
        .replace("+ -", "- ")
        .replace("1x", "x")
        .replace(" + - ", " - ")
        .replace("^1", "")
    )


def factors(n):
    result = []
    n = mpz(n)
    for i in range(1, gmpy2.isqrt(n) + 1):
        div, mod = divmod(n, i)
        if not mod:
            result.append(i)
    return result


def poly_synthetic_div(P, Q):
    lP = len(P)
    R = [0] * lP

    for i in range(0, lP):
        if i == 0:
            R[i] = P[i]
        else:
            R[i] = P[i] + Q * R[i - 1]
    return R


def get_rationals(poly, grade):
    tmp = []
    lP = len(poly)
    d = factors(abs(poly[-1]))
    if d == []:
        d = [abs(poly[-1])]
    n = factors(abs(grade - poly[0]))
    if n == []:
        n = [abs(poly[0])]
    # print d
    # print n
    for d_ in d:
        for n_ in n:
            div = float(d_) / n_
            if div > 0:
                tmp.append(div)
    tmp2 = []
    for r in set(sorted(tmp)):
        tmp2.append(r)
        tmp2.append(-r)
    return tmp2


def poly_to_text(poly, grade=0):
    lP = len(poly)
    tmp = []
    for i in range(0, lP):
        if grade - i > -1:
            if grade - i == 0:
                tmp.append("%d" % poly[i])
            else:
                tmp.append("%dx^%d" % (poly[i], grade - i))

    return sanitize(" + ".join(tmp))


def poly_synthetic_div_complete_step(poly, grade):
    print ("-" * 60)
    print ("Grade:", grade)
    print ("P = ", poly_to_text(poly, grade))
    print ("Coefs: P =", poly)
    rationals = get_rationals(poly, grade)
    print ("rationals:", rationals)
    term = []
    if len(rationals) > 0:
        for Q in rationals:
            R = poly_synthetic_div(poly, Q)
            if R[-1] == 0:
                print ("Q =", Q)
                print ("%d is divisor" % Q)
                print ("Coefs: R =", R)
                print ("R = ", poly_to_text(R, grade - 1))
            if R[-1] == 0:
                term = ["(x + %d)" % -Q]
                # break
                return R[:-1], term
        print ("No divisor found")
        return None
    else:
        print ("No rationals")
    return None


def factor_poly(Poly, Grade):
    P = Poly
    terms = []
    for grade in range(Grade, 1, -1):
        result = poly_synthetic_div_complete_step(P, grade)
        if result != None:
            P, term = result
            terms += term
        else:
            break
    terms += ["(%s)" % poly_to_text(P, grade)]
    print ("=" * 60)
    s = sanitize("".join(terms))
    print ("Result:", s)


#RUFFINI METHOD 
# tells if a n is prime or not
def isPrime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False

    return True


# finds the prime factors of n
def factors(n):
    factor = []
    limit = int(round(sqrt(n), 2)) + 1
    check = 2
    num = n
    if isPrime(n):
        return [n]
    for check in range(2, limit):
        if isPrime(check) and (num % check) == 0:
            factor.append(check)
            num /= check
            if isPrime(num):
                factor.append(num)
                break
    factor = sorted(factor)
    return factor


# add the negative factors to try
def addnegatives(D):
    nD = []
    for i in D:
        nD.append(-abs(i))
        nD.append(abs(i))
    return nD


# one step ruffini
def ruffini_step(P, D):

    for i in range(len(D)):
        tmpPoli = []
        for j in range(len(P)):
            if j == 0:
                tmpPoli.append(P[j])
            else:
                tmpPoli.append(P[j] + (D[i] * tmpPoli[j - 1]))
        if tmpPoli[len(tmpPoli) - 1] == 0:
            return [D[i], tmpPoli]


def ruffini_test(P):
    print ("P=", P)
    TI = P[len(P) - 1]
    D = [1] + factors(abs(TI)) + [abs(TI)]
    D = addnegatives(D)
    D.sort()

    tmp = P
    for k in range(len(P) - 3):
        ret = ruffini_step(tmp, D)
        tmp = ret[1]
        print ("Grade=", len(P) - k, "root=", ret[0], "coefs=", ret[1])


#ANALYS OF SERIES

def mean(L):
    """mean or average of all values in list"""

    tmp = sum(L) * 1.0
    l = len(L)
    return tmp / l


avg = mean


def stddev(X):
    """standar deviation calculaion of all values in the list"""

    l = len(X)

    def F(X):
        x = mean(X)
        s = 0
        for i in range(0, l):
            s += (X[i] - x) ** 2
        return s

    return math.sqrt((1.0 / l) * F(X))


def MAD(X):
    """Median Absolute deviation calculaion of all values in the list"""

    l = len(X)

    def F(X):
        x = mean(X)
        s = 0
        for i in range(0, l):
            s += abs(X[i] - x)
        return s

    return (1.0 / l) * F(X)


def bounds(X):
    """Upper and lower bounds"""

    SD = stddev(X)
    m = mean(X)
    return m - SD, SD + m


def simple_anonaly_detection(X):
    """A simple check if a value in a list is outside the bounds
    It should return tuples of (index,value)"""

    B = bounds(X)
    for i in range(0, len(X)):
        if X[i] < B[0] or X[i] > B[1]:
            yield (i, X[i])



def test(S):
    """
    Expected output:
    Series: [2, 3, 5, 2, 3, 12, 5, 3, 4]
    Mean: 4.333333333333333
    StdDev: 2.9059326290271157
    Bounds: (1.4274007043062173, 7.239265962360449)
    simple anomaly detection: [(5, 12)]
    """
   
    print("Series:", S)
    print("Mean:", mean(S))
    print("StdDev:", stddev(S))
    print("Bounds:", bounds(S))
    print("simple anomaly detection:", list(simple_anonaly_detection(S)))





    #First Derivative Tests
                    
def first_derivative_tests():

    function = input("Function: ").replace("^", "**")
    a = float(input("Left Endpoint: "))
    b = float(input("Right Endpoint: "))
    function = function.replace(' ', '')

    #Formats function input as a mathematical function of x
    def f(x):
        return eval(function.replace("x", "("+str(x)+")"))

    #Defenition of a derivative
    def derivative(x):
        h = 1/1000000
        rise = f(x + h) - f(x)
        run = h
        slope = rise / run
        return slope

    #Makes a list of the derivative at every thousandth of a point in the interval
    derivative_list = []
    for x in range(int(a)*1000, (int(b)*1000)+1):
        r = x/1000
        derivative_list.append([r, derivative(r)])

    #Finds critical points in the list, by checking if the values to the left and right of them change sign
    local_extrema = [[a, round(derivative(a), 3)]]
    for q in range(1,len(derivative_list)-1):
        this_deriv = derivative_list[q][1]
        if this_deriv > 0:
            prev_deriv = derivative_list[q-1][1]
            next_deriv = derivative_list[q+1][1]
            if next_deriv < 0 and prev_deriv > 0:
                local_extrema.append([round((derivative_list[q+1][0]+derivative_list[q][0])/2, 3), round((next_deriv+this_deriv)/2, 2)])
            if next_deriv > 0 and prev_deriv < 0:
                local_extrema.append([round((derivative_list[q-1][0]+derivative_list[q][0])/2, 3), round((prev_deriv+this_deriv)/2, 2)])
        elif this_deriv == 0:
            prev_deriv = derivative_list[q-1][1]
            next_deriv = derivative_list[q+1][1]
            if next_deriv > 0 and prev_deriv < 0:
                local_extrema.append(derivative_list[q])
                local_extrema.append(derivative_list[q])
            elif next_deriv < 0 and prev_deriv > 0:
                local_extrema.append(derivative_list[q])

    #Adds endpoints to critical points list
    local_extrema.append([b, round(derivative(b), 2)])

    #Neatly formats and prints Local Extrema
    l_extrema = "Extrema Points (X, Y): "
    for ty in local_extrema:
        l_extrema = l_extrema + " (" + str(ty[0]) + ", " + str(round(f(ty[0]), 3)) + ") "
    print(l_extrema)

    #Identifies increasing and decresing intervals using critical points, by checking first interval then alternating for next intervals
    increasing_ivals = "Increasing: "
    decreasing_ivals = "Decreasing: "
    isdone = False
    current_index = 0
    while not isdone:
        ival1 = local_extrema[current_index]
        ival2 = local_extrema[current_index + 1]
        is_increasing = False
        if f(ival1[0]) < f(ival2[0]):
            is_increasing = True
            increasing_ivals = increasing_ivals + " [" + str(ival1[0]) + ", " + str(ival2[0]) + "]"
        else:
            decreasing_ivals = decreasing_ivals + " [" + str(ival1[0]) + ", " + str(ival2[0]) + "]"
        current_index += 1
        if current_index > (len(local_extrema) - 2):
            isdone = True

    #Formats and prints intervals
    print(increasing_ivals)
    print(decreasing_ivals)



                    #Second Derivative Tests

def second_derivative_tests():
    
    function = input("Function: ").replace("^", "**")
    a = float(input("Left Endpoint: "))
    b = float(input("Right Endpoint: "))
    function = function.replace(' ', '')


    #Formats function input as a mathematical function of x
    def f(x):
        return eval(function.replace("x", "("+str(x)+")"))
    
    #Defenition of a derivative
    def derivative(x):
        h = 1/1000000
        rise = f(x + h) - f(x)
        run = h
        slope = rise / run
        return slope
        
    #Defenition of second derivative using defenition of first
    def second(x):
        h = 1/1000000
        rise = derivative(x + h) - derivative(x)
        run = h
        slope = rise / run
        return slope    

    #Makes a list of the second derivative at every thousandth of a point in the interval
    seconds_list = []
    for x in range(int(a)*1000, (int(b)*1000)+1):
        r = x/1000
        seconds_list.append([r, second(r)])

    #Finds inflection points in the list, by checking if the values to the left and right of them change sign
    inflection_points = [[a, round(second(a), 3)]]
    for q in range(1,len(seconds_list)-1):
        this_deriv = seconds_list[q][1]
        if this_deriv > 0:
            prev_deriv = seconds_list[q-1][1]
            next_deriv = seconds_list[q+1][1]
            if next_deriv < 0 and prev_deriv > 0:
                inflection_points.append([round((seconds_list[q+1][0]+seconds_list[q][0])/2, 3), round((next_deriv+this_deriv)/2, 2)])
            if next_deriv > 0 and prev_deriv < 0:
                inflection_points.append([round((seconds_list[q-1][0]+seconds_list[q][0])/2, 3), round((prev_deriv+this_deriv)/2, 2)])
        elif this_deriv == 0:
            prev_deriv = seconds_list[q-1][1]
            next_deriv = seconds_list[q+1][1]
            if next_deriv > 0 and prev_deriv < 0:
                inflection_points.append(seconds_list[q])
            elif next_deriv < 0 and prev_deriv > 0:
                inflection_points.append(seconds_list[q])
    inflection_points.append([b, round(second(b), 2)])

    #Identifies concave up and concave down intervals using points of inflection, by checking first interval then alternating for next intervals
    conup = "Concave Up: "
    condown = "Concave Down: "
    isfinished = False
    current_order = 0
    while not isfinished:
        ival1 = inflection_points[current_order]
        ival2 = inflection_points[current_order + 1]
        is_increasing = False
        if derivative(ival1[0]) < derivative(ival2[0]):
            is_increasing = True
            conup = conup + " (" + str(ival1[0]) + ", " + str(ival2[0]) + ")"
        else:
            condown = condown + " (" + str(ival1[0]) + ", " + str(ival2[0]) + ")"
        current_order += 1
        if current_order > (len(inflection_points) - 2):
            isfinished = True

    #Neatly formats and prints points of inflection
    del inflection_points[0]
    del inflection_points[-1]
    i_points = "Points of Inflection (X, Y): "
    for ty in inflection_points:
        i_points = i_points + " (" + str(ty[0]) + ", " + str(round(f(ty[0]), 3)) + ") "
    print(i_points)

    #Prints concave up and concave down intervals
    print(conup)
    print(condown)


                #Line Integral  
def lineintegral(x,y,z,f):

  import math
  from time import sleep

  # Edit x(t), y(t), z(t) and f(x,y,z) here:
  a = float(input("Starting t value (a): \n"))
  b = float(input("Ending t value (b): \n"))
  n = int(input("Number of subintervals (n): \n"))
  print(" ")
  print("Calculating . . . \n")

  def x1(t):
    h=1e-6
    return ((x(t+h) - x(t))/(h))
  def y1(t):
    h=1e-6
    return ((y(t+h) - y(t))/(h))
  def z1(t):
    h=1e-6
    return ((z(t+h) - z(t))/(h))
  def g(t):
    return f(x(t), y(t), z(t)) * math.sqrt((x1(t))**2 + (y1(t))**2 + (z1(t))**2)

  i = 1
  sum = 0
  k = 1e6
  dt = (b-a)/n
  while i <= n:
    sum += g(a + i * dt) * dt
    i+=1
  print(" ")

  print("The line integral along the function f(x,y,z) with a curve defined by r(t) = <x(t),y(t),z(t)> from t = " + str(a) + " to t = " + str(b) + " is approximately: \n")
  sleep(0.5)
  print(sum)

#Tangent Plane
def TangentPlane(f):

    #Any function z = f(x,y) here
    
  def f_x(x,y):  #Partial derivative with respect to x
    h = 1e-5
    return (f(x+h, y)-f(x-h, y))/(2*h)

  def f_y(x,y):  #Partial derivative with respect to y
    h = 1e-5
    return (f(x, y+h)-f(x, y-h))/(2*h)
  point_x = float(input("x-coordinate of the point: "))
  point_y = float(input("y-coordinate of the point: "))
  point_z = f(point_x, point_y)
  print("z-coordinate of the point: " + str(point_z))
  print("The tangent plane at the point " + "(" + str(point_x) + "," + str(point_y) + "," + str(point_z) + ") is: \n")

  a = f_x(point_x, point_y)
  b = f_y(point_x, point_y)
  print("z = " + str(round(a, 3)) + "(x - " + str(point_x) + ") + " + str(round(b, 3)) + "(y - " + str(round(point_y, 3)) + ") + " + str(round(point_z, 3)))

